﻿using System;

public class Room
{
	//field declaration, use _ before to identify private var, and use private var always
	private int _id;

	//constructor
	public Room()
	{
		_id = 0;

	}

	//id property
	public int Id
	{
		get
		{
			return _id;
		}
		set
		{
			_id = value;
		}
	}
}

