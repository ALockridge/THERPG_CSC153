﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/**

* 12/12/22

* CSC 153

* Aaingel Lockridge

* The RPG C# Edition

*/


namespace THERPG_CSC153
{
    class Program
    {
        static Random rnd = new Random();

        static void Main(string[] args)
        {
            StreamReader saveRead;
            StreamWriter saveWrite;
            int exit = 0;
            int health = 24;
            int currentRoom = 0;
            int ATK = 4;
            int randVal = 0;
            string[] rooms = {
                "in a grassy field",
                "at the Cave entrance",
                "in the inner Cave",
                "at the outer Cave",
                "at the Cave's exit"
            };
            string[] roomNames = {
                "field",
                "cave entrance",
                "inner Cave",
                "outer Cave",
                "Cave exit"
            };

            //MOB ASSIGNMENTS
            //MOB STATS, CORRESPOND TO POSITION IN LIST
            int[] mobHP = {
                18,
                64,
                84,
                220,
                100,
                300
            };
            int[] mobATK = {
                2,
                12,
                18,
                30,
                16,
                6
            };

            List<string> mobs = new List<string> {
                "Blob",
                "Skeleton",
                "Thief",
                "Robot",
                "Fire Monster",
                "Water Monster"
            };

            //POTIONS, TREASURES, WEAPONS, ITEMS
            string[] potions = {
                "HPotion",
                "ATonic"
            };
            string[] treasures = {
                "GOLD",
                "SILVER",
                "COPPER"
            };
            string[] weapons = {
                "Stick",
                "Dull Knife",
                "Sharp Knife",
                "Crowbar",
                "Shortsword"
            };
            List<string> items = new List<string> {
                "Key",
                "Stone",
                "Cloth",
                "Metal"
            };

   
           Console.BackgroundColor = ConsoleColor.Black;

            while (exit == 0)
            {

                Console.WriteLine(" _______ _            _____  _____   _____\n|__   __| |          |  __ \\|  __ \\ / ____|\n   | |  | |__   ___  | |__) | |__) | |  __\n   | |  | '_ \\ / _ \\ |  _  /|  ___/| | |_ |\n   | |  | | | |  __/ | | \\ \\| |    | |__| |\n   |_|  |_| |_|\\___| |_|  \\_\\_|     \\_____|");
                Console.WriteLine("███████████████████████████████████████████ ");
                Console.WriteLine("                         |            |");
                Console.WriteLine("                         |            |");
                Console.WriteLine("                         |            |");
                Console.WriteLine("                         |1] NEW GAME |");
                Console.WriteLine("                         |2] CONTINUE |");
                Console.WriteLine("                         |3] EXIT     |");
                Console.WriteLine("                         |/\\/\\/\\/\\/\\/\\|");
                string saveloaddiag = Console.ReadLine();
                //save/load
                if (saveloaddiag == "2")
                {
                    try
                    {
                        saveRead = File.OpenText("theSave.txt");
                        if (saveRead.EndOfStream == true)
                        {
                            Console.WriteLine("no savefile, creating one..");

                        }
                        while (saveRead.EndOfStream == false)
                        {
                            Console.WriteLine(saveRead.ReadLine());
                        }
                        saveRead.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }

                }

                //Main menu

                while (exit == 0)
                {

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("you are " + rooms[currentRoom]);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(" | (room #" + currentRoom + ")");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("HP:", health);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("╦═══");
                    Console.WriteLine("╠1] - MOVE NORTH");
                    Console.WriteLine("╠2] - MOVE SOUTH");
                    Console.WriteLine("╠3] - ATTACK");
                    Console.WriteLine("╠4] - EXIT");
                    Console.WriteLine("╩═══");
                    Console.Write("O>> ");
                    Console.ForegroundColor = ConsoleColor.Blue;

                    currentRoom = MoveCheck(currentRoom, randVal);

                } //exit = false first while
            }
        }
        public static int MoveCheck(int currentRoom, int randVal)
        {
            string input = Console.ReadLine();
            switch (input)
            {
                //DIRECTIONAL MOVEMENT
                case "1":
                    if (currentRoom < 4) { currentRoom++; return currentRoom; }
                    break;
                case "2":
                    if (currentRoom > 0) { currentRoom--; return currentRoom; }
                    break;
                default:
                    Console.WriteLine("error: BAD INPUT");
                    break;
                case "3":
                    randVal = rnd.Next(0, 21);
                    Console.WriteLine(randVal);
                    return randVal;
            }
            return currentRoom;
        }

    }




}